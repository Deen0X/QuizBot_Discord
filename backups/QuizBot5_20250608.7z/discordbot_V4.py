# ======== discordbot.py (Versión Corregida) ========
import sys
import discord
import logging
import random
import os
from datetime import datetime
from discord.ext import commands
import json
import asyncio
from buttons_discord import (
    InteractiveButton, 
    PersistentButtonView,
    save_buttons,
    load_buttons,
    create_theme_message,
    BUTTON_THEMES
)
from generator_quiz import QuizGenerator
from generator_eval import EvalGenerator
from utils import Utils

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Variable global para vistas persistentes
persistent_views = {}

async def button_callback(interaction: discord.Interaction):
    """Callback base para botones"""
    await interaction.response.send_message(
        "Botón presionado!", 
        ephemeral=True
    )

def generate_random_buttons(count: int, random_id: int) -> list[InteractiveButton]:
    """Genera botones de ejemplo con mensajes aleatorios"""
    buttons = []
    
    for i in range(1, count + 1):
        buttons.append(
            InteractiveButton(
                label=f"Button {i} {random_id}",
                style=discord.ButtonStyle.primary,
                callback=button_callback,
                message=f"Hello from button {i}! {random_id}",
                direct_message=f"Thanks for clicking button {i}! {random_id}",
                option_reply=f"Opción de respuesta {i} {random_id}",
            )
        )
    return buttons

# ======== Función pública: Verificar mensaje existente
async def message_exists(bot: commands.Bot, channel_id: int, message_id: int) -> bool:
    """Verifica si un mensaje existe en un canal"""
    try:
        channel = bot.get_channel(channel_id)
        if channel:
            message = await channel.fetch_message(message_id)
            return message is not None
    except discord.NotFound:
        return False
    except Exception as e:
        logging.error(f"Error verificando mensaje {message_id}: {e}")
        return False
    return False

# -------- Método privado: Limpiar botones inexistentes
async def cleanup_nonexistent_buttons(bot: commands.Bot, all_buttons: dict) -> dict:
    """Elimina botones de mensajes que ya no existen"""
    cleaned_buttons = {}
    for message_id, buttons in all_buttons.items():
        try:
            # Extraer channel_id del primer botón (asumimos mismo canal)
            if buttons and hasattr(buttons[0], 'channel_id'):
                channel_id = buttons[0].channel_id
                exists = await message_exists(bot, channel_id, int(message_id))
                if exists:
                    cleaned_buttons[message_id] = buttons
                else:
                    logging.info(f"Eliminando botones de mensaje inexistente: {message_id}")
            else:
                cleaned_buttons[message_id] = buttons
        except Exception as e:
            logging.error(f"Error limpiando botones {message_id}: {e}")
            continue
    
    return cleaned_buttons


def start_bot():
    """Inicia y configura el bot de Discord"""
    config = Utils.leer_config()
    if not config:
        print("No se pudo cargar el archivo config.json")
        return

    token = config.get("TOKEN")
    command_prefix = config.get("COMMAND_PREFIX", "!")

    intents = discord.Intents.default()
    intents.message_content = True
    intents.messages = True  # Añadir este intent
    intents.guilds = True    # Añadir este intent

    bot = commands.Bot(
        command_prefix=command_prefix,
        intents=intents,
        help_command=None
    )

    @bot.event
    async def on_ready():
        """Evento cuando el bot está listo"""
        print(f"***********************\nBot conectado como {bot.user} (ID: {bot.user.id})\n***********************")

        # Cargar y limpiar botones persistentes
        all_buttons = load_buttons()
        cleaned_buttons = await cleanup_nonexistent_buttons(bot, all_buttons)
        
        # Guardar cambios si hubo limpieza
        if len(cleaned_buttons) != len(all_buttons):
            save_buttons("buttons.json", cleaned_buttons)
        
        loaded_count = 0
        loaded_views = 0

        # Cargar botones persistentes
        all_buttons = load_buttons()
        for message_id, buttons in all_buttons.items():
            try:
                view = PersistentButtonView(int(message_id), buttons)
                bot.add_view(view)
                persistent_views[int(message_id)] = view
                #logging.info(f"Vista persistente cargada para mensaje {message_id}")
                loaded_count += len(buttons)
                loaded_views += 1
            except Exception as e:
                logging.error(f"Error cargando vista {message_id}: {e}")

        # Mostrar resumen de carga
        if loaded_count > 0:
            logging.info(f"Se han cargado {loaded_count} botones persistentes")
            print(f"✅ Se han cargado {loaded_count} botones persistentes")
        else:
            logging.info("No se encontraron botones persistentes para cargar")
            print("ℹ️ No se encontraron botones persistentes para cargar")            

        if loaded_views > 0:
            logging.info(f"Se han cargado {loaded_views} vistas persistentes")
            print(f"✅ Se han cargado {loaded_views} vistas persistentes")
        else:
            logging.info("No se encontraron vistas persistentes para cargar")
            print("ℹ️ No se encontraron vistas persistentes para cargar")       

        print("\n\nBot inicializado!")


    @bot.event
    async def on_command_error(ctx, error):
        """Manejo de errores de comandos"""
        if isinstance(error, commands.CommandNotFound):
            await ctx.send("Comando no encontrado. Usa !help para ver los comandos disponibles.")
        else:
            logging.error(f"Error en comando: {error}")

    # ======== COMANDO: button (botón único) ========
    @bot.command(name="button")
    async def show_button(ctx):
        """Muestra un solo botón interactivo"""
        button = InteractiveButton(
            label="Click Me",
            style=discord.ButtonStyle.primary,
            callback=button_callback,
            message="Hello from single button!",
            direct_message="Thanks for clicking the single button!"
        )

        view = PersistentButtonView(ctx.message.id, [button])
        bot.add_view(view)
        save_buttons(str(ctx.message.id), [button])  # Convertir a str para consistencia
        
        await ctx.send("Single button:", view=view)

    # ======== COMANDO: buttons (múltiples botones) ========
    @bot.command(name="buttons")
    async def show_multiple_buttons(ctx):
        """Muestra múltiples botones aleatorios"""
        random_id = random.randint(10000, 99999)
        num_buttons = random.randint(3, 6)
        buttons = generate_random_buttons(num_buttons, random_id)

        view = PersistentButtonView(ctx.message.id, buttons)
        bot.add_view(view)
        save_buttons(str(ctx.message.id), buttons)
        
        await ctx.send(f"Here are {num_buttons} buttons:", view=view)

    # ======== COMANDO: theme (botones temáticos) ========
    @bot.command(name="theme")
    async def show_theme_buttons(ctx, theme: str = "random"):
        """Muestra botones con temas visuales"""
        num_buttons = random.randint(3, 6)
        random_id = random.randint(10000, 99999)
        options = generate_random_buttons(num_buttons, random_id)
        if theme.startswith("bool"):
            options = options[:2]  # Limitar a 2 opciones para temas booleanos
        
        embed, themed_buttons = create_theme_message(
            f"**Encuesta de ejemplo {random_id}**",
            options,
            theme
        )
        
        view = PersistentButtonView(ctx.message.id, themed_buttons)
        bot.add_view(view)
        save_buttons(str(ctx.message.id), themed_buttons)
        
        await ctx.send(embed=embed, view=view)

    @bot.command(name="quiz")
    async def generate_quiz_text_message(ctx, theme: str = "random", silentmode: bool = False):
        """Genera un quiz como texto plano con botones temáticos"""
        try:
            status_message = await ctx.send("🧠 Generando nuevo quiz...", silent = silentmode)

            # Obtener el nombre del canal
            channel_name = ctx.channel.name if hasattr(ctx.channel, "name") else ""

            # Determinar módulo según el nombre del canal o parámetro theme
            module_name = ""

            if channel_name.startswith("quizbot_"):
                # Extraer lo que sigue a "quizbot_"
                module_name = channel_name[len("quizbot_"):]
            #else:
            #    # Si no, usar el parámetro theme si se pasó
            #    if theme and theme.lower() != "random":
            #        module_name = theme.lower()

            generator = QuizGenerator()
            quiz = generator.generate_quiz(module_name)

            print("Quiz generado exitosamente:")
            print(json.dumps(quiz, indent=2, ensure_ascii=False))

            if not quiz:
                #await ctx.send("No se pudo generar el quiz.")
                await status_message.edit(content="No se pudo generar el quiz.")
                return

            # Asegurarnos que correct_answer es una lista (backward compatibility)
            if isinstance(quiz.get("correct_answer"), int):
                quiz["correct_answer"] = [quiz["correct_answer"]]

            metadata = quiz.get("metadata")
            # Seleccionar tema visual
            if theme == "random":
                theme = random.choice(list(BUTTON_THEMES.keys()))
                while theme.startswith("bool") and len(quiz["options"]) > 2:
                    theme = random.choice(list(BUTTON_THEMES.keys()))

            symbols = BUTTON_THEMES.get(theme, BUTTON_THEMES["letters"])

            metadata = quiz.get("metadata", {})
            # Construir el texto plano con símbolos y respuestas
            question_text = (
                f"> 🧠 Tipo: Generado por IA 🤖\n"
                f"> 📚 **Módulo:** {metadata.get('module')}\n"
                f"> 📝 **{metadata['section']} - {metadata['subsection']}**\n"
                f"> 🔍 **Fuente:** {quiz['title']}\n"
                f"> ❓ **Pregunta:**\n"
                f"> ```ini\n> [{quiz['question']}]\n> ```\n"
                f"> 📋 **Selecciona la respuesta correcta:**\n> \n"
            )

            #for idx, option in enumerate(quiz["options"]):
            #    symbol = symbols[idx] if idx < len(symbols) else str(idx + 1)
            #    # Marcar opciones correctas con un emoji
            #    is_correct = " ✅" if idx in quiz["correct_answer"] else ""
            #    question_text += f"> {symbol} - {option['text']}{is_correct}\n"

            

            for idx, option in enumerate(quiz["options"]):
                symbol = symbols[idx] if idx < len(symbols) else str(idx + 1)
                question_text += f"> {symbol} - {option['text']}\n"

            message_template = Utils.load_template("message_chat_template.txt")
            dm_template = Utils.load_template("message_dm_template.txt")

            print(f'message_link:{f"https://discord.com/channels/{ctx.guild.id}/{ctx.channel.id}/{status_message.id}"}')
            #reemplaza dinámicamente valores antes de enviar el mensaje.
            replacements = {
                "{module}": str(metadata.get('module')),
                "{message_id}": str(status_message.id),
                "{message_link}": f"https://discord.com/channels/{ctx.guild.id}/{ctx.channel.id}/{status_message.id}"
            }

            for placeholder, value in replacements.items():
                message_template = message_template.replace(placeholder, value)

            for placeholder, value in replacements.items():
                dm_template = dm_template.replace(placeholder, value)


            # Crear botones temáticos con feedback
            themed_buttons = []
            #print(f"______________ quiz['correct_answer']={quiz['correct_answer']}")

            for idx, option in enumerate(quiz["options"]):
                symbol = symbols[idx] if idx < len(symbols) else str(idx + 1)

                ## Determinar si es respuesta correcta
                #is_correct = idx in quiz["correct_answer"]

                themed_buttons.append(
                    InteractiveButton(
                        label=symbol,
                        style=discord.ButtonStyle.secondary,
                        callback=button_callback,
                        message=Utils.apply_replacements(message_template, Utils.generate_option_replacements(quiz, idx, symbol)),
                        direct_message=Utils.apply_replacements(dm_template, Utils.generate_option_replacements(quiz, idx, symbol)),
                        option_reply=option["text"],
                        prefix_theme=symbol
                    )
                )
            
            #view = PersistentButtonView(ctx.message.id, themed_buttons)
            view = PersistentButtonView(status_message.id, themed_buttons)
            bot.add_view(view)
            #save_buttons(str(ctx.message.id), themed_buttons)
            save_buttons("buttons.json", {str(status_message.id): themed_buttons})

            #await status_message.delete()
            #await ctx.send(question_text, view=view)

            # Enviar media si existe, editando el status_message
            media_path = str(quiz.get("media_question", "")).strip()
            if media_path and os.path.exists(media_path):
                file = discord.File(media_path)
                await status_message.edit(content=question_text, attachments=[file], view=view)
            else:
                await status_message.edit(content=question_text, view=view)

        except Exception as e:
            logging.error(f"Error al generar quiz: {str(e)}")
            await ctx.send(f"❌ Ocurrió un error al generar el quiz. (¿Existe el módulo '{module_name}'?)")

    @bot.command(name="quizzes")
    async def send_10_quizzes(ctx, theme: str = "random"):
        """Genera 10 quizzes consecutivos con delay configurable"""
        try:
            # Obtener delay de config.json
            config = Utils.leer_config()
            delay_seconds = config.get("QUIZ_DELAY_SECONDS", 5) # Valor por defecto: 5 segundos
            total_quizzes = config.get("TOTAL_QUIZZES", 5) # Valor por defecto: 5 segundos

            # Mensaje inicial
            start_msg = await ctx.send(f"🚀 Iniciando generación de {total_quizzes} quizzes (delay: {delay_seconds}s)...")

            # Generar quizzes
            for i in range(1, total_quizzes + 1):
                try:
                    # Crear y eliminar mensaje temporal
                    quiz_msg = await ctx.send(f"📝 Generando quiz {i}/{total_quizzes}...", silent=True)
                    #quiz_msg = await ctx.send_silent_message(f"📝 Generando quiz {i}/{total_quizzes}...")
                    #quiz_msg = await send_silent_message(ctx, f"📝 Generando quiz {i}/{total_quizzes}...")
                    
                    await generate_quiz_text_message(ctx, theme, True)
                    await quiz_msg.delete()
                    
                    if i < total_quizzes:
                        await asyncio.sleep(delay_seconds)
                except discord.HTTPException as e:
                    logging.warning(f"Error manejando mensajes (quiz {i}): {str(e)}")
                    continue  # Continuar con el siguiente quiz

            # Mensaje final
            await ctx.send(content=f"✅ ¡{total_quizzes} quizzes generados exitosamente!")
            
        except Exception as e:
            logging.error(f"Error en quiz10: {str(e)}")
            await ctx.send("❌ Error al generar los quizzes. Ver logs.")


    #Este comando limpia los botones del bot solo en el canal donde se ejecuta.
    @bot.command(name='limpiar')
    @commands.has_permissions(manage_messages=True)
    async def limpiar(ctx):
        """Limpia el canal actual y elimina solo sus botones persistentes"""
        try:
            # 1. Obtener todos los IDs de mensajes del canal actual
            channel_message_ids = {str(msg.id) async for msg in ctx.channel.history(limit=None)}
            
            # 2. Cargar todos los botones existentes
            all_buttons = load_buttons()
            
            # 3. Eliminar solo los botones del canal actual
            buttons_to_keep = {
                msg_id: buttons for msg_id, buttons in all_buttons.items() 
                if msg_id not in channel_message_ids
            }
            
            # 4. Guardar solo si hubo cambios
            if len(buttons_to_keep) != len(all_buttons):
                save_buttons("buttons.json", buttons_to_keep)
                logging.info(f"Eliminados {len(all_buttons)-len(buttons_to_keep)} botones del canal {ctx.channel.id}")
            
            # 5. Limpiar el canal
            await ctx.channel.purge()
            await ctx.send("✅ Canal limpiado y botones persistentes actualizados.", delete_after=3)
            
        except discord.Forbidden:
            await ctx.send("❌ No tengo permisos para borrar mensajes.")
        except Exception as e:
            logging.error(f"Error en comando limpiar: {e}")
            await ctx.send(f"❌ Error al limpiar: {e}")

    # ======== COMANDO: eval (evaluación con botones temáticos) ========
    @bot.command(name="eval1")
    async def generate_eval_text_message1(ctx, theme: str = "random", silentmode: bool = False):
        """Genera una evaluación como texto plano con botones temáticos"""
        try:
            status_message = await ctx.send("📝 Generando evaluación...", silent=silentmode)

            # Obtener el nombre del canal
            channel_name = ctx.channel.name if hasattr(ctx.channel, "name") else ""

            # Determinar módulo según el nombre del canal o parámetro theme
            module_name = ""

            if channel_name.startswith("quizbot_"):
                # Extraer lo que sigue a "quizbot_"
                module_name = channel_name[len("quizbot_"):]

            generator = EvalGenerator()
            eval_data = generator.generate_eval(module_name)

            print("Evaluación generada exitosamente:")
            print(json.dumps(eval_data, indent=2, ensure_ascii=False))

            if not eval_data:
                await status_message.edit(content="No se pudo generar la evaluación.")
                return

            pregunta = eval_data.get('question', '')
            opciones = pregunta.get('opciones', [])
            respuestas = pregunta.get('respuestas', [])
            ## Asegurarnos que correct_answer es una lista (backward compatibility)
            #if isinstance(eval_data.get("correct_answer"), int):
            #    eval_data["correct_answer"] = [eval_data["correct_answer"]]
            metadata = eval_data.get("metadata", {})
            # Seleccionar tema visual
            if theme == "random":
                theme = random.choice(list(BUTTON_THEMES.keys()))
                while theme.startswith("bool") and len(eval_data["options"]) > 2:
                    theme = random.choice(list(BUTTON_THEMES.keys()))

            symbols = BUTTON_THEMES.get(theme, BUTTON_THEMES["letters"])

            # Construir el texto plano con símbolos y respuestas
            question_text = (
                f"> 🧠 **Tipo:** Evaluación obtenida de Autoevaluación 👤\n"
                f"> 📚 **Módulo:** {metadata.get('module', 'General')}\n"
                f"> 📝 **{metadata.get('section', 'Evaluación')} - {metadata.get('subsection', 'Pregunta')}**\n"
                f"> 🔍 **Fuente:** {eval_data['title']}\n"
                f"> ❓ **Pregunta:**\n"
                f"> ```ini\n> [{pregunta['enunciado']}]\n> ```\n"
                f"> 📋 **Selecciona la respuesta correcta:**\n> \n"
            )

            print(f"question_text={question_text}")

            for idx, option in enumerate(eval_data["options"]):
                symbol = symbols[idx] if idx < len(symbols) else str(idx + 1)
                question_text += f"> {symbol} - {option['text']}\n"

            message_template = Utils.load_template("message_chat_eval_template.txt")
            dm_template = Utils.load_template("message_dm_eval_template.txt")

            # Reemplazos dinámicos
            replacements = {
                "{module}": str(metadata.get('module', 'General')),
                "{message_id}": str(status_message.id),
                "{message_link}": f"https://discord.com/channels/{ctx.guild.id}/{ctx.channel.id}/{status_message.id}"
            }

            for placeholder, value in replacements.items():
                message_template = message_template.replace(placeholder, value)
                dm_template = dm_template.replace(placeholder, value)

            # Crear botones temáticos con feedback
            themed_buttons = []
            for idx, option in enumerate(eval_data["options"]):
                symbol = symbols[idx] if idx < len(symbols) else str(idx + 1)

                themed_buttons.append(
                    InteractiveButton(
                        label=symbol,
                        style=discord.ButtonStyle.secondary,
                        callback=button_callback,
                        message=Utils.apply_replacements(message_template, Utils.generate_option_replacements(eval_data, idx, symbol)),
                        direct_message=Utils.apply_replacements(dm_template, Utils.generate_option_replacements(eval_data, idx, symbol)),
                        option_reply=option["text"],
                        prefix_theme=symbol
                    )
                )
            
            view = PersistentButtonView(status_message.id, themed_buttons)
            bot.add_view(view)
            save_buttons("buttons.json", {str(status_message.id): themed_buttons})

            # Enviar media si existe, editando el status_message
            media_path = str(eval_data.get("media_question", "")).strip()
            if media_path and os.path.exists(media_path):
                file = discord.File(media_path)
                await status_message.edit(content=question_text, attachments=[file], view=view)
            else:
                await status_message.edit(content=question_text, view=view)

        except Exception as e:
            logging.error(f"Error al generar evaluación: {str(e)}")
            await ctx.send(f"❌ Ocurrió un error al generar la evaluación. (¿Existe el módulo '{module_name}'?)")

    # ======== COMANDO: evals (múltiples evaluaciones) ========
    @bot.command(name="evals")
    async def send_multiple_evals(ctx, theme: str = "random"):
        """Genera múltiples evaluaciones consecutivas con delay configurable"""
        try:
            # Obtener delay de config.json
            config = Utils.leer_config()
            delay_seconds = config.get("EVAL_DELAY_SECONDS", 5) # Valor por defecto: 5 segundos
            total_evals = config.get("TOTAL_EVALS", 5) # Valor por defecto: 5 evaluaciones

            # Mensaje inicial
            start_msg = await ctx.send(f"🚀 Iniciando generación de {total_evals} evaluaciones (delay: {delay_seconds}s)...")

            # Generar evaluaciones
            for i in range(1, total_evals + 1):
                try:
                    # Crear y eliminar mensaje temporal
                    eval_msg = await ctx.send(f"📝 Generando evaluación {i}/{total_evals}...", silent=True)
                    await generate_eval_text_message(ctx, theme, True, "none")
                    await eval_msg.delete()
                    
                    if i < total_evals:
                        await asyncio.sleep(delay_seconds)
                except discord.HTTPException as e:
                    logging.warning(f"Error manejando mensajes (evaluación {i}): {str(e)}")
                    continue  # Continuar con la siguiente evaluación

            # Mensaje final
            await ctx.send(content=f"✅ ¡{total_evals} evaluaciones generadas exitosamente!")
            
        except Exception as e:
            logging.error(f"Error en evals: {str(e)}")
            await ctx.send("❌ Error al generar las evaluaciones. Ver logs.")

    @bot.command(name="remixes")
    async def send_multiple_evals(ctx, theme: str = "random"):
        """Genera múltiples evaluaciones consecutivas con delay configurable"""
        try:
            # Obtener delay de config.json
            config = Utils.leer_config()
            delay_seconds = config.get("REMIX_DELAY_SECONDS", 5) # Valor por defecto: 5 segundos
            total_evals = config.get("TOTAL_REMIX", 5) # Valor por defecto: 5 evaluaciones

            # Mensaje inicial
            start_msg = await ctx.send(f"🚀 Iniciando generación de {total_evals} evaluaciones Remixed! 🎛️🤖(delay: {delay_seconds}s)...")

            # Generar evaluaciones
            for i in range(1, total_evals + 1):
                try:
                    # Crear y eliminar mensaje temporal
                    eval_msg = await ctx.send(f"🎛️ Remixing evaluación {i}/{total_evals}...", silent=True)
                    await generate_eval_text_message(ctx, theme, True, "remix")
                    #await generate_eval_text_message(ctx=ctx, theme = "random", silentmode = True, remix_mode="remix"):
                    await eval_msg.delete()
                    
                    if i < total_evals:
                        await asyncio.sleep(delay_seconds)
                except discord.HTTPException as e:
                    logging.warning(f"Error manejando mensajes (evaluación {i}): {str(e)}")
                    continue  # Continuar con la siguiente evaluación

            # Mensaje final
            await ctx.send(content=f"✅ ¡{total_evals} remixes generados!")
            
        except Exception as e:
            logging.error(f"Error en evals: {str(e)}")
            await ctx.send("❌ Error al generar las evaluaciones. Ver logs.")

    # ======== COMANDO: eval (evaluación con botones temáticos) ========
    @bot.command(name="remix", aliases=["remix1", "remixx", "remixb", "laura", "eval"])
    async def generate_eval_text_message(ctx, theme: str = "random", silentmode: bool = False, remix_mode : str=""):
        """Genera una evaluación como texto plano con botones temáticos"""
        command_used = ctx.invoked_with
        try:
            status_message = await ctx.send("🎛️ Remixing evaluación..." if remix_mode != "none" else "🔍 Buscando evaluación...", silent=silentmode)

            # Obtener el nombre del canal
            channel_name = ctx.channel.name if hasattr(ctx.channel, "name") else ""

            # Determinar módulo según el nombre del canal o parámetro theme
            module_name = ""
            remix_selected=""

            if channel_name.startswith("quizbot_"):
                # Extraer lo que sigue a "quizbot_"
                module_name = channel_name[len("quizbot_"):]

            if remix_mode!="none":
                if not remix_mode:
                    remix_mode = command_used
                shortcut_map = {
                    "remixb": "remix_bool",
                    "remix1": "remix_single",
                    "remixx": "remix_multi",
                    "laura": "remix",
                    "eval": "none"
                }
                
                if not remix_mode:
                    remix_options = [
                        #"remix_bool",
                        "remix_single",
                        #"remix_multi",
                        "remix"
                    ]
                    remix_selected = random.choice(remix_options)
                else:
                    remix_selected = shortcut_map.get(remix_mode, remix_mode)
                
                type_eval="👤🎛️🤖"
            else:
                type_eval="👤"

            print (f"remix_selected:{remix_selected}")
            generator = EvalGenerator()
            eval_data = generator.generate_eval(module_name, remix_selected)

            pregunta = eval_data.get('question', '')
            opciones = pregunta.get('opciones', [])
            respuestas = pregunta.get('respuestas', [])
            metadata = eval_data.get("metadata", {})


            print("Evaluación generada exitosamente:")
            print(json.dumps(eval_data, indent=2, ensure_ascii=False))

            if not eval_data:
                await status_message.edit(content="No se pudo generar la evaluación.")
                return

            # Asegurarnos que correct_answer es una lista (backward compatibility)
            if isinstance(eval_data.get("correct_answer"), int):
                eval_data["correct_answer"] = [eval_data["correct_answer"]]

            #metadata = eval_data.get("metadata", {})
            # Seleccionar tema visual
            if theme == "random":
                theme = random.choice(list(BUTTON_THEMES.keys()))
                while theme.startswith("bool") and len(eval_data["options"]) > 2:
                    theme = random.choice(list(BUTTON_THEMES.keys()))

            symbols = BUTTON_THEMES.get(theme, BUTTON_THEMES["letters"])

            # Construir el texto plano con símbolos y respuestas
            question_text = (
                f"> 🧠 **Tipo:** Evaluación **Remixed** obtenida de Autoevaluación {type_eval}\n"
                f"> 📚 **Módulo:** {metadata.get('module', 'General')}\n"
                f"> 📝 **{metadata.get('section', 'Evaluación')} - {metadata.get('subsection', 'Pregunta')}**\n"
                #f"> 🔍 **Fuente:** {eval_data['source']}\n" options
                f"> ❓ **Pregunta:**\n"
                f"> ```ini\n> [{pregunta['enunciado']}]\n> ```\n"
                f"> 📋 **Selecciona la respuesta correcta:**\n> \n"
            )

            print (print("# " * 20))
            print(f"question_text:\n{question_text}")
            print (print("# " * 20))

            #for idx, option in enumerate(eval_data["options"]):
            for idx, option in enumerate(opciones):
                symbol = symbols[idx] if idx < len(symbols) else str(idx + 1)
                #question_text += f"> {symbol} - {option['text']}\n"
                question_text += f"> {symbol} - {option}\n"

            message_template = Utils.load_template("message_chat_eval_template.txt")
            dm_template = Utils.load_template("message_dm_eval_template.txt")

            # Reemplazos dinámicos
            replacements = {
                "{module}": str(metadata.get('module', 'General')),
                "{message_id}": str(status_message.id),
                "{message_link}": f"https://discord.com/channels/{ctx.guild.id}/{ctx.channel.id}/{status_message.id}"
            }

            try:
                for placeholder, value in replacements.items():
                    message_template = message_template.replace(placeholder, value)
                    dm_template = dm_template.replace(placeholder, value)
            except Exception as e:
                print (f"[ERROR] {e}")
                
            # Crear botones temáticos con feedback
            themed_buttons = []
            #for idx, option in enumerate(eval_data["options"]):
            for idx, option in enumerate(opciones):
                symbol = symbols[idx] if idx < len(symbols) else str(idx + 1)

                themed_buttons.append(
                    InteractiveButton(
                        label=symbol,
                        style=discord.ButtonStyle.secondary,
                        callback=button_callback,
                        message=Utils.apply_replacements(message_template, Utils.generate_option_replacements(eval_data, idx, symbol)),
                        direct_message=Utils.apply_replacements(dm_template, Utils.generate_option_replacements(eval_data, idx, symbol)),
                        option_reply=option["text"],
                        prefix_theme=symbol
                    )
                )
            
            view = PersistentButtonView(status_message.id, themed_buttons)
            bot.add_view(view)
            save_buttons("buttons.json", {str(status_message.id): themed_buttons})

            # Enviar media si existe, editando el status_message
            media_path = str(eval_data.get("media_question", "")).strip()
            if media_path and os.path.exists(media_path):
                file = discord.File(media_path)
                await status_message.edit(content=question_text, attachments=[file], view=view)
            else:
                await status_message.edit(content=question_text, view=view)

        except Exception as e:
            logging.error(f"Error al generar evaluación: {str(e)}")
            await ctx.send(f"❌ Ocurrió un error al generar la evaluación. (¿Existe el módulo '{module_name}'?)")

    @bot.command(name="exam")
    async def send_multiple_tests(ctx, theme: str = "random"):
        """Genera múltiples preguntas de evaluación con delay configurable"""
        try:
            config = Utils.leer_config()
            delay_seconds = config.get("QUIZ_DELAY_SECONDS", 5)
            total_questions = config.get("TOTAL_QUIZZES", 5)

            start_msg = await ctx.send(f"🚀 Iniciando generación de {total_questions} preguntas (delay: {delay_seconds}s)...")

            # Cargar botones existentes primero
            all_buttons = load_buttons()
            
            for i in range(1, total_questions + 1):
                try:
                    temp_msg = await ctx.send(f"📝 Generando pregunta {i}/{total_questions}...", silent=True)
                    await generate_test_question(ctx, theme, True)
                    await temp_msg.delete()
                    
                    if i < total_questions:
                        await asyncio.sleep(delay_seconds)
                except discord.HTTPException as e:
                    logging.warning(f"Error manejando mensajes (pregunta {i}): {str(e)}")
                    continue

            await ctx.send(content=f"✅ ¡{total_questions} preguntas generadas exitosamente!")
            
        except Exception as e:
            logging.error(f"Error en tests: {str(e)}")
            await ctx.send("❌ Error al generar las preguntas. Ver logs.")

    #Este comando limpia todos los botones del bot en todas las salas. cuidado!
    @bot.command(name='limpiartodo')
    @commands.has_permissions(manage_messages=True)
    async def limpiartodo(ctx):
        try:
            # Obtener todos los mensajes del canal
            messages = [message async for message in ctx.channel.history(limit=None)]
            message_ids = {str(msg.id) for msg in messages}
            
            # Cargar botones existentes
            all_buttons = load_buttons()
            
            # Filtrar solo botones de este canal
            buttons_to_keep = {}
            for msg_id, buttons in all_buttons.items():
                # Asumimos que si el mensaje está en el historial, existe
                if msg_id in message_ids:
                    buttons_to_keep[msg_id] = buttons
            
            # Guardar cambios si hubo limpieza
            if len(buttons_to_keep) != len(all_buttons):
                save_buttons("buttons.json", buttons_to_keep)
            
            await ctx.channel.purge()
            await ctx.send("✅ Canal limpiado y botones persistentes actualizados.", delete_after=3)
        except discord.Forbidden:
            await ctx.send("❌ No tengo permisos para borrar mensajes.")
        except Exception as e:
            await ctx.send(f"❌ Error al limpiar: {e}")

    # ======== INICIAR BOT ========
    try:
        bot.run(token)
    except discord.LoginError:
        logging.error("Token de bot inválido")
    except Exception as e:
        logging.error(f"Error al iniciar bot: {e}")

if __name__ == "__main__":
    start_bot()