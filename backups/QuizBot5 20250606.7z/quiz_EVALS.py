import json
import sys
from picker_EVALS import EvalPicker

class QuizGeneratorEVALS:
    def __init__(self):
        self.picker = EvalPicker()

    def generate_quiz(self, module="", unit="", question_id="", count=1):
        """Convierte preguntas de EVALS al formato estándar de quiz."""
        # 1. Obtener preguntas usando el picker
        eval_data = self.picker.pick_questions(module, unit, question_id, count)
        if "error" in eval_data:
            return eval_data

        # 2. Convertir al formato estándar
        quizzes = []
        for question in eval_data["preguntas"]:
            quiz = {
                "title": f"Pregunta {question['numero']}",
                "question": question["enunciado"],
                "options": [{"text": opt, "feedback": ""} for opt in question["opciones"]],
                "correct_answer": int(question["respuestas"][0]) if question["respuestas"] else 0,
                "link_question": None,
                "media_question": None,
                "module": eval_data["module"],
                "unidad": question["origen"]["unidad"],
                "question_id": question["numero"],
                "type_quiz": question["type_quiz"]
            }
            quizzes.append(quiz)

        return {
            "quizzes": quizzes,
            "total_quizzes": len(quizzes)
        }

if __name__ == "__main__":
    generator = QuizGeneratorEVALS()
    
    # Procesar argumentos (mismos que picker_EVALS.py)
    args = sys.argv[1:]
    module = args[0] if len(args) > 0 else ""
    unit = args[1] if len(args) > 1 else ""
    question_id = args[2] if len(args) > 2 else ""
    count = int(args[3]) if len(args) > 3 else 1
    
    quiz = generator.generate_quiz(module, unit, question_id, count)
    print(json.dumps(quiz, indent=2, ensure_ascii=False))