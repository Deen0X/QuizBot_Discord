import os
import json
import random
import sys
from utils import Utils

class ContentPicker:
    def __init__(self):
        self.config = Utils.load_config()
        self.MIN_ELEGIBLE = self.config.get("MIN_ELEGIBLE", 50)
        self.MIN_AUXILIAR = self.config.get("MIN_AUXILIAR", 30)
        self.SUFIX_MODULE = self.config.get("SUFIX_CONTENTS_NAME", "")

    def normalize_module_name(self, module_name):
        """Añade sufijo al nombre del módulo si no lo tiene"""
        if not module_name.endswith(self.SUFIX_MODULE):
            return f"{module_name}{self.SUFIX_MODULE}"
        return module_name

    def normalize_unit_name(self, unit_name):
        """Añade 'Unidad ' al número si no está presente"""
        if not unit_name.startswith("Unidad "):
            return f"Unidad {unit_name.strip()}"
        return unit_name

    def normalize_paragraph_id(self, paragraph_id):
        """Añade 'P' al ID si no está presente"""
        if isinstance(paragraph_id, int):
            return f"P{paragraph_id}"
        if not paragraph_id.startswith("P"):
            return f"P{paragraph_id.strip()}"
        return paragraph_id

    def load_module_contents(self, module_name):
        """Carga el JSON de contenidos del módulo especificado."""
        normalized_name = self.normalize_module_name(module_name)
        base_path = Utils.get_base_path("CONTENTS")
        json_path = os.path.join(base_path, f"{normalized_name}.json")
        if not os.path.exists(json_path):
            return None
        with open(json_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def get_random_paragraph(self, contents, unit_filter=None, paragraph_id=None):
        """Selecciona un párrafo aleatorio (con filtros opcionales)."""
        paragraphs = []
        for content in contents["contenidos"]:
            # Si se filtra por unidad, normalizar el nombre
            if unit_filter:
                normalized_unit = self.normalize_unit_name(unit_filter)
                if content["unidad"] != normalized_unit:
                    continue
            
            for section in content["sections"]:
                for subsection in section["subsections"]:
                    for idx, paragraph in enumerate(subsection["paragraphs"]):
                        # Si se busca por ID, normalizarlo
                        if paragraph_id:
                            normalized_id = self.normalize_paragraph_id(paragraph_id)
                            if paragraph["id"] != normalized_id:
                                continue
                        paragraphs.append((content, section, subsection, idx, paragraph))
        
        if not paragraphs:
            return None
        return random.choice(paragraphs)

    def expand_context(self, subsection, current_idx, direction):
        """Expande el contexto (anterior/posterior) hasta cumplir MIN_AUXILIAR."""
        context = []
        remaining_chars = self.MIN_AUXILIAR
        step = -1 if direction == "previous" else 1
        idx = current_idx + step
        
        while 0 <= idx < len(subsection["paragraphs"]) and remaining_chars > 0:
            paragraph = subsection["paragraphs"][idx]
            context.append(paragraph)
            remaining_chars -= len(paragraph["text"])
            idx += step
        
        return context if context else [{"text": "", "links": [], "media": []}]

    def pick_content(self, module="", unit="", paragraph_id=""):
        """Método principal para seleccionar contenido."""
        # 1. Cargar módulo (aleatorio si no se especifica)
        if not module:
            modules = [f.split(".")[0] for f in os.listdir(Utils.get_base_path("CONTENTS")) 
                      if f.endswith(f"{self.SUFIX_MODULE}.json")]
            if not modules:
                return {}
            module = random.choice(modules)
        else:
            module = self.normalize_module_name(module)
        
        contents = self.load_module_contents(module)
        if not contents:
            return {}
        
        # 2. Determinar parámetros de búsqueda
        use_unit = None if paragraph_id else unit
        use_paragraph_id = self.normalize_paragraph_id(paragraph_id) if paragraph_id else ""
        
        # 3. Seleccionar párrafo
        selected = self.get_random_paragraph(contents, use_unit, use_paragraph_id)
        if not selected:
            return {}
        
        content, section, subsection, p_idx, paragraph = selected
        
        # 4. Validar MIN_ELEGIBLE
        if len(paragraph["text"]) < self.MIN_ELEGIBLE:
            return self.pick_content(module, unit, paragraph_id)  # Reintentar
        
        # 5. Obtener contexto
        previous = self.expand_context(subsection, p_idx, "previous")
        next_ = self.expand_context(subsection, p_idx, "next")
        
        return {
            "module": module.replace(self.SUFIX_MODULE, ""),  # Quitar sufijo en la salida
            "selected_paragraph": {
                **paragraph,  # Incluye todos los campos existentes
                "type": subsection["type"]  # <-- Añade el type
            },
            "previous_paragraph": [{
                **p, 
                "type": subsection["type"]  # Para cada párrafo anterior
            } for p in previous],
            "next_paragraph": [{
                **p,
                "type": subsection["type"]  # Para cada párrafo siguiente
            } for p in next_],
            "metadata": {
                "unidad": content["unidad"],
                "archivo": content["archivo"],
                "section_title": section["title"]
            }
        }

if __name__ == "__main__":
    picker = ContentPicker()
    
    # Procesar argumentos
    args = sys.argv[1:]
    module = args[0] if len(args) > 0 else ""
    unit = args[1] if len(args) > 1 else ""
    paragraph_id = args[2] if len(args) > 2 else ""
    
    content = picker.pick_content(module, unit, paragraph_id)
    print(json.dumps(content, indent=2, ensure_ascii=False))