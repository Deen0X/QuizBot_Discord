import os
import json
import re
from bs4 import BeautifulSoup
from utils import Utils

question_counter = 1


def parse_all_evaluations():
    global question_counter
    base_path = Utils.get_base_path("EVALS")
    if not os.path.exists(base_path):
        print(f"Error: Directorio base no encontrado: {base_path}")
        return

    modules = [m for m in os.listdir(base_path) 
               if os.path.isdir(os.path.join(base_path, m)) and not m.endswith("_files")]
    
    for module_name in modules:
        module_path = os.path.join(base_path, module_name)
        module_questions = []
        question_counter = 1
        
        # Procesar todas las unidades del módulo
        for unit_name in os.listdir(module_path):
            unit_path = os.path.join(module_path, unit_name)
            if not os.path.isdir(unit_path) or unit_name.endswith("_files"):
                continue
            
            # Procesar todos los usuarios de la unidad
            for user_name in os.listdir(unit_path):
                user_path = os.path.join(unit_path, user_name)
                if not os.path.isdir(user_path):
                    continue
                
                # Procesar todos los archivos HTML del usuario
                for file_name in os.listdir(user_path):
                    if not file_name.lower().endswith(".html"):
                        continue
                    
                    file_path = os.path.join(user_path, file_name)
                    questions = parse_evaluation_file(file_path, module_name, unit_name, user_name, file_name)
                    
                    # Añadir preguntas únicas al módulo
                    for q in questions:
                        if not any(q['enunciado'] == existing['enunciado'] for existing in module_questions):
                            q['numero'] = str(question_counter)
                            module_questions.append(q)
                            question_counter += 1
        
        # Guardar todas las preguntas del módulo
        save_module_evaluations(module_path, module_name, module_questions)

def process_evaluation_module(module_path, module_name):
    global question_counter
    unique_questions = []
    
    for root, dirs, files in os.walk(module_path):
        if root.endswith("_files"):
            continue
            
        for file_name in files:
            if not file_name.lower().endswith(".html"):
                continue
                
            file_path = os.path.join(root, file_name)
            questions = parse_evaluation_file(file_path)
            
            for q in questions:
                if not any(q['enunciado'] == existing['enunciado'] for existing in unique_questions):
                    q['numero'] = str(question_counter)
                    unique_questions.append(q)
                    question_counter += 1
    
    save_module_evaluations(module_path, module_name, unique_questions)

def parse_evaluation_file(file_path, module_name, unit_name, user_name, file_name):
    with open(file_path, "r", encoding="utf-8") as f:
        soup = BeautifulSoup(f, 'html.parser')
    
    questions = []
    question_divs = soup.find_all('div', class_='que')

    for div in question_divs:
        options = get_question_options(div)
        feedback = get_question_feedback(div)
        correct_indices = get_correct_answer_indices_from_feedback(options, feedback)
        quiz_type = determine_quiz_type(div, options)
        
        question = {
            'numero': len(questions) + 1,
            'enunciado': get_question_text(div),
            'opciones': options,
            'respuestas': correct_indices,
            'retroalimentacion': feedback,
            'type_quiz': quiz_type,
            'media': get_question_media(div),
            'links': get_question_links(div),
            'origen': {
                'modulo': module_name,
                'unidad': unit_name,
                'usuario': user_name,
                'archivo': file_name
            }
        }
        
        # Handle combo questions (matching type)
        if quiz_type == "combo":
            question['combo_options'] = get_combo_options(div)
        
        questions.append(question)
    
    return questions

def get_question_number(div):
    number_tag = div.find('span', class_='qno')
    return number_tag.text.strip() if number_tag else "N/A"

def get_question_text(div):
    qtext_div = div.find('div', class_='qtext')
    if not qtext_div:
        return "N/A"
    
    text = '\n'.join([p.get_text(' ', strip=True) for p in qtext_div.find_all(['p', 'br']) if p.get_text(strip=True)])
    return text if text else qtext_div.get_text(' ', strip=True)

def get_question_options(div):
    """Extrae texto de opciones limpiando formato"""
    options = []
    answer_div = div.find('div', class_='answer')
    
    if answer_div:
        for option in answer_div.find_all('div', class_=['r0', 'r1']):
            text_div = option.find('div', class_='flex-fill') or \
                      option.find('div', {'data-region': 'answer-label'})
            
            if text_div:
                text = ' '.join(text_div.get_text(' ', strip=True).split())
                clean_text = re.sub(r'^[a-z]\.\s*', '', text, flags=re.IGNORECASE)
                options.append(clean_text.strip())
    
    # Si no encontramos opciones pero es una pregunta V/F
    if not options and is_boolean_feedback(get_question_feedback(div)):
        return ['Verdadero', 'Falso']
    
    return options

def get_correct_answer_indices_from_feedback(options, feedback):
    """Identifica respuestas correctas comparando opciones con feedback"""
    if feedback == "N/A":
        return []
    
    # Manejo específico para preguntas Verdadero/Falso
    boolean_match = re.match(r"La respuesta correcta es '(Verdadero|Falso)'", feedback)
    if boolean_match:
        correct_answer = boolean_match.group(1)
        return ['0'] if correct_answer == 'Verdadero' else ['1']
    
    if not options:
        return []
    
    # Extraer el texto de feedback limpio (sin etiquetas HTML ni formato)
    feedback_text = re.sub(r'<[^>]+>', '', feedback)  # Eliminar tags HTML
    feedback_text = re.sub(r'^Las? respuestas? correctas? (es|son):\s*', '', feedback_text, flags=re.IGNORECASE)
    feedback_text = feedback_text.strip().rstrip('.')
    
    # Normalizar espacios y comillas
    feedback_text = ' '.join(feedback_text.split())
    feedback_text = feedback_text.replace('“', '"').replace('”', '"')
    
    # Para preguntas múltiples, dividir por comas pero mantener frases completas
    feedback_parts = []
    current_part = []
    in_quotes = False
    
    for char in feedback_text:
        if char == '"':
            in_quotes = not in_quotes
            current_part.append(char)
        elif char == ',' and not in_quotes:
            feedback_parts.append(''.join(current_part).strip())
            current_part = []
        else:
            current_part.append(char)
    
    if current_part:
        feedback_parts.append(''.join(current_part).strip())
    
    # Comparar cada opción con cada parte del feedback
    correct_indices = []
    for idx, option in enumerate(options):
        # Limpiar la opción (similar a como limpiamos el feedback)
        clean_option = ' '.join(option.split())
        clean_option = clean_option.replace('“', '"').replace('”', '"')
        
        # Buscar coincidencia exacta (ignorando mayúsculas)
        for part in feedback_parts:
            if clean_option.lower() == part.lower():
                correct_indices.append(str(idx))
                break
    
    return correct_indices

def get_question_feedback(div):
    """Extrae texto de feedback conservando espacios"""
    feedback_div = div.find('div', class_='rightanswer')
    if not feedback_div:
        return "N/A"
    
    # Procesar contenido conservando estructura de espacios
    parts = []
    for content in feedback_div.contents:
        if isinstance(content, str):
            parts.append(content.strip())
        elif content.name:
            parts.append(content.get_text(' ', strip=True))
    
    return ' '.join(parts).strip()

def determine_quiz_type(div, options):
    """Determina el tipo de pregunta basado en su estructura HTML"""
    if div.find('input', {'type': 'radio'}):
        # Verificar si es pregunta V/F
        feedback = get_question_feedback(div)
        if is_boolean_feedback(feedback) or (len(options) == 2 and is_boolean_question(options)):
            return "boolean"
        return "single"
    elif div.find('input', {'type': 'checkbox'}):
        return "multiple"
    elif div.find('input', {'type': 'text'}):
        return "text"
    elif div.find('select'):
        return "combo"
    
    question_text = get_question_text(div).lower()
    if "relacionar" in question_text or "emparejar" in question_text:
        return "combo"
    
    return "unknown"


def is_boolean_feedback(feedback):
    """Determina si el feedback es de una pregunta Verdadero/Falso"""
    return bool(re.match(r"La respuesta correcta es '(Verdadero|Falso)'", feedback))

def is_boolean_question(options):
    bool_options = {'verdadero', 'falso', 'true', 'false', 'si', 'no'}
    return all(any(op in opt.lower() for op in bool_options) for opt in options)

def get_combo_options(div):
    """Obtiene opciones de combos para preguntas de matching"""
    select = div.find('select')
    if not select:
        return []
    
    return [option.get_text(strip=True) for option in select.find_all('option') if option.get_text(strip=True)]

def get_question_media(div):
    qtext_div = div.find('div', class_='qtext')
    if not qtext_div:
        return []
    
    media = []
    for img in qtext_div.find_all('img', src=True):
        media.append({
            'src': img['src'],
            'alt': img.get('alt', ''),
            'title': img.get('title', '')
        })
    return media

def get_question_links(div):
    qtext_div = div.find('div', class_='qtext')
    if not qtext_div:
        return []
    
    links = []
    for a in qtext_div.find_all('a', href=True):
        links.append({
            'href': a['href'],
            'text': a.get_text(strip=True)
        })
    return links

def save_module_evaluations(module_path, module_name, questions):
    output = {
        "module": module_name,
        "total_preguntas": len(questions),
        "preguntas": questions
    }
    
    # El archivo JSON se guarda en el directorio del módulo con el nombre del módulo + _evals.json
    config_file = Utils.load_config()
    sufix_name=config_file.get("SUFIX_EVALS_NAME")
    print (f"sufix_name:",sufix_name)
    
    base_path = Utils.get_base_path("EVALS")
    #output_path = os.path.join(module_path, f"{module_name}{sufix_name}.json")
    output_path = os.path.join(base_path, f"{module_name}{sufix_name}.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"[OK] Evaluaciones de {module_name} guardadas en {output_path}")

if __name__ == "__main__":
    parse_all_evaluations()
